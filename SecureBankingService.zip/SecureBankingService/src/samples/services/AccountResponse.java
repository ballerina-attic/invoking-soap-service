/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package samples.services;

import java.util.HashMap;

public class AccountResponse {

        public static AccountDetails acc1 = new AccountDetails(2417254, "Alice", 250000.00);
        public static AccountDetails acc2 = new AccountDetails(2987321, "Bob", 500000.00);

        public static HashMap<Integer, AccountDetails> hmap = new HashMap<Integer, AccountDetails>();
        public static boolean isInitialized = false;


    public static void initAccountResponse(){
        if(!isInitialized) {
            hmap.put(2417254, acc1);
            hmap.put(2987321, acc2);
            isInitialized = true;
        }
    }

    public static AccountDetails fetchAccountDetails(int accNo) throws Exception{
        System.out.println("Comes to fetch part\n");
        if(!hmap.containsKey(accNo)){
            throw new Exception("Account Not Found in the Database");
        }
        // return new AccountDetails(request.getAccountNo());
        return hmap.get(accNo);
    }

    public static AccountDetails updateAccountDetails(int accNo, double balance) throws Exception{
        if (!hmap.containsKey(accNo)) {
            throw new Exception("Account Not Found in the Database");
        }

        AccountDetails temp = hmap.get(accNo);
        temp.setAccountBalance(balance);
        hmap.put(accNo, temp);
        return temp;
    }

    public static AccountDetails deleteAccountDetails(int accNo) throws Exception{
        if(!hmap.containsKey(accNo)){
            throw new Exception("Account Not Found in the Database: Already Removed");
        }

        hmap.remove(accNo);
        String success = "Account : " + accNo + " Deleted Successfully";
        String failure = "Account : " + accNo + " Deletion Failed";
        String msg = hmap.containsKey(accNo) ? failure : success;
        AccountDetails newAcc = new AccountDetails(msg);
        // return hmap.containsKey(accNo);
        return newAcc;
    }

    public static AccountDetails createAccountDetails(int accNo, String accHolderName, double balance) throws Exception{
        if(hmap.containsKey(accNo)) {
            throw new Exception("Account creation failed : Account already exists");
        }

        AccountDetails newAcc = new AccountDetails(accNo, accHolderName, balance);
        hmap.put(accNo, newAcc);
        return hmap.get(accNo);
    }

}
