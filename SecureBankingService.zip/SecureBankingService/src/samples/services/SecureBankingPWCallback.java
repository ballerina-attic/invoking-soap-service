// package samples.userguide;


// import com.sun.xml.wss.impl.callback.PasswordValidationCallback;
// import java.io.IOException;
// import javax.security.auth.callback.Callback;
// import javax.security.auth.callback.UnsupportedCallbackException;

// public class SecureBankingPWCallback implements PasswordValidationCallback.PasswordValidator{

//     @Override
//     public boolean validate(PasswordValidationCallback.Request request) throws PasswordValidationCallback.PasswordValidationException {

//         PasswordValidationCallback.PlainTextPasswordRequest ptreq;

//         ptreq = (PasswordValidationCallback.PlainTextPasswordRequest) request;

//         return "wso2ballerina".equals(ptreq.getUsername()) &&
//             "wso2ballerina".equals(ptreq.getPassword());
//     }
    
// }

// package samples.userguide;

// import org.apache.ws.security.WSPasswordCallback;
 
// import javax.security.auth.callback.Callback;
// import javax.security.auth.callback.CallbackHandler;
// import javax.security.auth.callback.UnsupportedCallbackException;
    
// import java.io.IOException;

// public class SecureBankingPWCallback implements CallbackHandler
// {
//         /**
//      * Field key
//      */

//     private static final byte[] key = {

//         (byte) 0x31, (byte) 0xfd, (byte) 0xcb, (byte) 0xda, (byte) 0xfb,

//         (byte) 0xcd, (byte) 0x6b, (byte) 0xa8, (byte) 0xe6, (byte) 0x19,

//         (byte) 0xa7, (byte) 0xbf, (byte) 0x51, (byte) 0xf7, (byte) 0xc7,

//         (byte) 0x3e, (byte) 0x80, (byte) 0xae, (byte) 0x98, (byte) 0x51,

//         (byte) 0xc8, (byte) 0x51, (byte) 0x34, (byte) 0x04,

//     };

//     /*

//     * (non-Javadoc)

//     * @see javax.security.auth.callback.CallbackHandler#handle(javax.security.auth.callback.Callback[])

//     */


//     /**
//      * Method handle
//      *
//      * @param callbacks
//      * @throws IOException
//      * @throws UnsupportedCallbackException
//      *
//      */
//     public void handle(Callback[] callbacks)
//         throws IOException, UnsupportedCallbackException {
//         for (int i = 0; i < callbacks.length; i++) {
//             WSPasswordCallback pwcb = (WSPasswordCallback)callbacks[i];
//             String id = pwcb.getIdentifer();
//             if (pwcb.getUsage() == WSPasswordCallback.USERNAME_TOKEN_UNKNOWN) {
 
//                 // used when plain-text password in message
//                 if (!"wso2ballerina".equals(id) || !"wso2ballerina".equals(pwcb.getPassword())) {
//                     throw new UnsupportedCallbackException(callbacks[i], "check failed");
//                 }
 
//             }
//         }
//     }
// }